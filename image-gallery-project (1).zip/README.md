
# Responsive Image Gallery

## Features
- Responsive HTML/CSS image gallery
- JavaScript lightbox
- Next/Previous image navigation
- Hover effects and smooth transitions
- Category filters
- Mobile-friendly design

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Project Structure
- index.html
- style.css
- script.js
